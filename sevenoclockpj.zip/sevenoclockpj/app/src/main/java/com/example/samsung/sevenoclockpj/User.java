package com.example.samsung.sevenoclockpj;

public class User {
    private String displayName;
    private String userID;
    private String currentDeviceToken;
    private int age=0;
    private String userLocation;
    private boolean randomMatching=false;
    private String userNickname;

    public User() {

    }

    public User(String userID, String displayName, String currentDeviceToken) {
        this(userID, displayName);
        setCurrentDeviceToken(currentDeviceToken);
    }

    public User(String userID, String displayName) {
        setDisplayName(displayName);
        setUserID(userID);
        currentDeviceToken = "";
    }

    public User(String userID , String displayName  , int age , String userLocation ){
        setDisplayName(displayName);
        setUserID(userID);
        currentDeviceToken = "";
        setAge(age);
        setUserLocation(userLocation);
        setRandomMatching(randomMatching);
    }


    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getCurrentDeviceToken() {
        return currentDeviceToken;
    }

    public void setCurrentDeviceToken(String currentDeviceToken) {
        this.currentDeviceToken = currentDeviceToken;
    }
    public void setAge(int age){ this.age = age;}

    public int getAge(){return age;}

    public  void  setUserLocation(String userLocation){this.userLocation = userLocation;}

    public  String getUserLocation(){return userLocation;}

    public  void  setRandomMatching(boolean randomMatching){this.randomMatching = randomMatching;}

    public  boolean getRandomMatchin(){return randomMatching;}

    public  void setUserNickname(String userNickname){this.userNickname = userNickname;}
    public  String getUserNickname(){return userNickname;}

}
